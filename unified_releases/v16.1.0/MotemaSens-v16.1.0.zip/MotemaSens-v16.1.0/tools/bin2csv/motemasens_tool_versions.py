"""Version numbers for MotemaSens desktop tools."""

APP_VERSION = "16.1.0"
FACTORY_FLASHER_VERSION = APP_VERSION
SW_UPDATER_VERSION = APP_VERSION
